package oauth

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"

	"github.com/stretchr/testify/require"

	"github.com/openai/tunnel-client/pkg/headerscope"
)

func TestBuildResourceMetadataURLs(t *testing.T) {
	t.Parallel()

	testCases := []struct {
		name string
		raw  string
		want []string
	}{
		{
			name: "path-specific",
			raw:  "https://example.com/public/mcp",
			want: []string{
				"https://example.com/.well-known/oauth-protected-resource/public/mcp",
				"https://example.com/.well-known/oauth-protected-resource",
			},
		},
		{
			name: "root-only",
			raw:  "https://example.com/",
			want: []string{"https://example.com/.well-known/oauth-protected-resource"},
		},
		{
			name: "trailing-slash-path",
			raw:  "https://example.com/public/mcp/",
			want: []string{
				"https://example.com/.well-known/oauth-protected-resource/public/mcp",
				"https://example.com/.well-known/oauth-protected-resource",
			},
		},
		{
			name: "already-well-known",
			raw:  "https://example.com/.well-known/oauth-protected-resource/public/mcp",
			want: []string{
				"https://example.com/.well-known/oauth-protected-resource/public/mcp",
				"https://example.com/.well-known/oauth-protected-resource",
			},
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			serverURL, err := url.Parse(tc.raw)
			require.NoError(t, err)

			got := metadataURLsToStrings(BuildResourceMetadataURLs(serverURL))
			require.Equal(t, tc.want, got)
		})
	}
}

func metadataURLsToStrings(urls []*url.URL) []string {
	out := make([]string, 0, len(urls))
	for _, u := range urls {
		if u == nil {
			continue
		}
		out = append(out, u.String())
	}
	return out
}

func candidateURLsToStrings(candidates []DiscoveryCandidate) []string {
	out := make([]string, 0, len(candidates))
	for _, candidate := range candidates {
		if candidate.URL == nil {
			continue
		}
		out = append(out, candidate.URL.String())
	}
	return out
}

func testLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func TestTryWWWAuthenticateProbeRedactsURLAndPreservesCause(t *testing.T) {
	t.Parallel()

	serverURL, err := url.Parse(
		"https://userinfo-value:credential-value@auth.internal/token-path-value?client_id=query-value#state=fragment-value",
	)
	require.NoError(t, err)
	original := serverURL.String()

	var requestURL string
	client := &http.Client{
		Transport: roundTripperFunc(func(req *http.Request) (*http.Response, error) {
			requestURL = req.URL.String()
			return nil, context.DeadlineExceeded
		}),
	}
	var logBuffer bytes.Buffer
	logger := slog.New(slog.NewJSONHandler(&logBuffer, nil))

	_, probeErr := tryWWWAuthenticateProbe(
		context.Background(),
		client,
		serverURL,
		logger,
		http.MethodPost,
	)
	require.Error(t, probeErr)
	require.ErrorIs(t, probeErr, context.DeadlineExceeded)
	require.Equal(t, original, serverURL.String())
	require.Equal(t, original, requestURL)

	var logRecord map[string]any
	require.NoError(t, json.NewDecoder(&logBuffer).Decode(&logRecord))
	require.Equal(t, "oauth discovery WWW-Authenticate probe failed", logRecord["msg"])
	logError, ok := logRecord["error"].(string)
	require.True(t, ok)
	for name, value := range map[string]string{
		"returned error": probeErr.Error(),
		"log error":      logError,
	} {
		require.Contains(t, value, "https://auth.internal", name)
		for _, sensitive := range []string{
			"userinfo-value",
			"credential-value",
			"token-path-value",
			"query-value",
			"fragment-value",
		} {
			require.NotContains(t, value, sensitive, name)
		}
	}
}

func TestTryWWWAuthenticateProbeRedactsAndPreservesResourceMetadataParseError(t *testing.T) {
	t.Parallel()

	const sensitiveMetadataURL = "https://userinfo-value:credential-value@auth.internal/%invalid-path-value"
	client := &http.Client{
		Transport: roundTripperFunc(func(req *http.Request) (*http.Response, error) {
			header := make(http.Header)
			header.Set("WWW-Authenticate", fmt.Sprintf(`Bearer resource_metadata="%s"`, sensitiveMetadataURL))
			return &http.Response{
				StatusCode: http.StatusUnauthorized,
				Header:     header,
				Body:       io.NopCloser(strings.NewReader("")),
				Request:    req,
			}, nil
		}),
	}
	serverURL, err := url.Parse("https://mcp.internal/resource")
	require.NoError(t, err)

	_, probeErr := tryWWWAuthenticateProbe(
		context.Background(),
		client,
		serverURL,
		testLogger(),
		http.MethodPost,
	)
	require.Error(t, probeErr)
	var urlErr *url.Error
	require.True(t, errors.As(probeErr, &urlErr))
	require.NotContains(t, probeErr.Error(), "userinfo-value")
	require.NotContains(t, probeErr.Error(), "credential-value")
	require.NotContains(t, probeErr.Error(), "invalid-path-value")
}

func TestParseResourceMetadataFromWWWAuthenticate(t *testing.T) {
	t.Parallel()

	testCases := []struct {
		name      string
		header    string
		want      string
		expectErr bool
	}{
		{
			name:   "quoted",
			header: `Bearer realm="demo", resource_metadata="https://example.com/pr"`,
			want:   "https://example.com/pr",
		},
		{
			name:   "bare",
			header: "Bearer resource_metadata=https://example.com/pr",
			want:   "https://example.com/pr",
		},
		{
			name:   "multiple challenges picks bearer",
			header: `Basic realm="legacy", Bearer realm="demo", resource_metadata="https://example.com/pr"`,
			want:   "https://example.com/pr",
		},
		{
			name:      "ignores non bearer resource metadata",
			header:    `Basic realm="legacy", resource_metadata="https://evil.example/pr"`,
			expectErr: true,
		},
		{
			name:      "missing",
			header:    `Bearer realm="demo"`,
			expectErr: true,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			parsed, err := parseResourceMetadataFromWWWAuthenticate(tc.header)
			if tc.expectErr {
				require.Error(t, err)
				return
			}
			require.NoError(t, err)
			require.Equal(t, tc.want, parsed.String())
		})
	}
}

func TestBuildOAuthDiscoveryCandidatesProbeUsesDiscoveryContext(t *testing.T) {
	t.Parallel()

	probeURL := "https://mcp.example.test/.well-known/oauth-protected-resource/context"
	var methods []string
	client := &http.Client{
		Transport: roundTripperFunc(func(req *http.Request) (*http.Response, error) {
			methods = append(methods, req.Method)
			require.True(t, headerscope.IsMCPDiscovery(req.Context()), "probe should mark requests as MCP discovery")
			require.Equal(t, "application/json", req.Header.Get("Accept"))
			require.NotEmpty(t, req.Header.Get("User-Agent"))

			statusCode := http.StatusUnauthorized
			header := make(http.Header)
			header.Set("WWW-Authenticate", fmt.Sprintf(`Bearer resource_metadata="%s"`, probeURL))
			if req.Method == http.MethodPost {
				statusCode = http.StatusNotFound
				header = make(http.Header)
			}
			return &http.Response{
				StatusCode: statusCode,
				Header:     header,
				Body:       io.NopCloser(strings.NewReader("")),
				Request:    req,
			}, nil
		}),
	}
	serverEndpoint, err := url.Parse("https://mcp.example.test/public/mcp")
	require.NoError(t, err)

	candidates, probe, err := BuildOAuthDiscoveryCandidates(
		context.Background(),
		client,
		serverEndpoint,
		testLogger(),
	)
	require.NoError(t, err)
	require.NotNil(t, probe)
	require.True(t, probe.Attempted)
	require.Equal(t, probeURL, probe.URL)
	require.Equal(t, []string{http.MethodPost, http.MethodGet}, methods)
	require.Equal(t, DiscoverySourceWWWAuthenticate, candidates[0].Source)
}

func TestOAuthDiscoveryUsesAllWWWAuthenticateFields(t *testing.T) {
	t.Parallel()

	for _, test := range []struct {
		name   string
		fields []string
	}{
		{name: "single bearer", fields: []string{`Bearer resource_metadata="%s"`}},
		{name: "combined challenges", fields: []string{`Basic realm="legacy", Bearer resource_metadata="%s"`}},
		{name: "bearer after basic", fields: []string{`Basic realm="legacy"`, `Bearer resource_metadata="%s"`}},
		{name: "bearer before basic", fields: []string{`Bearer resource_metadata="%s"`, `Basic realm="legacy"`}},
	} {
		t.Run(test.name, func(t *testing.T) {
			t.Parallel()

			var serverURL string
			server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				switch r.URL.Path {
				case "/mcp":
					for _, field := range test.fields {
						w.Header().Add("WWW-Authenticate", strings.ReplaceAll(field, "%s", serverURL+"/custom-metadata"))
					}
					w.WriteHeader(http.StatusUnauthorized)
				case "/custom-metadata":
					w.Header().Set("Content-Type", "application/json")
					_, _ = fmt.Fprintf(w, `{"resource":%q,"authorization_servers":[%q]}`, serverURL+"/mcp", serverURL+"/issuer")
				default:
					http.NotFound(w, r)
				}
			}))
			t.Cleanup(server.Close)
			serverURL = server.URL
			endpoint, err := url.Parse(server.URL + "/mcp")
			require.NoError(t, err)

			candidates, probe, err := BuildOAuthDiscoveryCandidates(context.Background(), server.Client(), endpoint, testLogger())
			require.NoError(t, err)
			response, sourceURL, attempts, err := FetchOAuthMetadata(context.Background(), server.Client(), candidates, testLogger())
			require.NoError(t, err, "discovery must work when only the advertised custom metadata endpoint exists")
			require.NotNil(t, response)
			require.Equal(t, server.URL+"/custom-metadata", sourceURL.String())
			require.NotNil(t, probe)
			require.Empty(t, probe.Error)
			require.Equal(t, sourceURL.String(), probe.URL)
			require.Equal(t, DiscoverySourceWWWAuthenticate, candidates[0].Source)
			require.True(t, attempts[0].Selected)
		})
	}
}

func TestBuildOAuthDiscoveryCandidatesRequiresLogger(t *testing.T) {
	t.Parallel()

	serverEndpoint, err := url.Parse("https://example.com/public/mcp")
	require.NoError(t, err)

	_, _, err = BuildOAuthDiscoveryCandidates(
		context.Background(),
		http.DefaultClient,
		serverEndpoint,
		nil,
	)
	require.Error(t, err)
}

func TestBuildOAuthDiscoveryCandidatesProbeFirst(t *testing.T) {
	t.Parallel()

	probePath := "/.well-known/oauth-protected-resource/custom"
	var serverURL string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost && r.URL.Path == "/public/mcp" {
			w.Header().Set("WWW-Authenticate", fmt.Sprintf(`Bearer resource_metadata="%s"`, serverURL+probePath))
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		http.NotFound(w, r)
	}))
	t.Cleanup(server.Close)
	serverURL = server.URL

	serverEndpoint, err := url.Parse(server.URL + "/public/mcp")
	require.NoError(t, err)

	candidates, probe, err := BuildOAuthDiscoveryCandidates(
		context.Background(),
		server.Client(),
		serverEndpoint,
		testLogger(),
	)
	require.NoError(t, err)

	require.NotNil(t, probe)
	require.True(t, probe.Attempted)
	require.Equal(t, server.URL+probePath, probe.URL)
	require.NotEmpty(t, candidates)
	require.Equal(t, DiscoverySourceWWWAuthenticate, candidates[0].Source)

	expected := []string{
		server.URL + probePath,
		server.URL + "/.well-known/oauth-protected-resource/public/mcp",
		server.URL + "/.well-known/oauth-protected-resource",
	}
	require.Equal(t, expected, candidateURLsToStrings(candidates))
}

func TestOAuthDiscoveryWithMultipleAuthenticateChallenges(t *testing.T) {
	t.Parallel()

	const bearer = `Bearer resource_metadata="{metadata}"`
	for _, tc := range []struct {
		name    string
		headers []string
	}{
		{name: "single", headers: []string{bearer}},
		{name: "combined", headers: []string{`Basic realm="enterprise", ` + bearer}},
		{name: "bearer_first", headers: []string{bearer, `Basic realm="enterprise"`}},
		{name: "bearer_last", headers: []string{`Basic realm="enterprise"`, bearer}},
	} {
		for _, method := range []string{http.MethodPost, http.MethodGet} {
			t.Run(tc.name+"/"+method, func(t *testing.T) {
				t.Parallel()

				server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
					switch {
					case r.URL.Path == "/mcp" && r.Method == method:
						for _, header := range tc.headers {
							w.Header().Add("WWW-Authenticate", strings.ReplaceAll(header, "{metadata}", "http://"+r.Host+"/custom-metadata"))
						}
						w.WriteHeader(http.StatusUnauthorized)
					case r.URL.Path == "/custom-metadata":
						w.Header().Set("Content-Type", "application/json")
						_, _ = fmt.Fprintf(w, `{"resource":"http://%s/mcp"}`, r.Host)
					default:
						http.NotFound(w, r)
					}
				}))
				t.Cleanup(server.Close)

				endpoint, err := url.Parse(server.URL + "/mcp")
				require.NoError(t, err)
				candidates, probe, err := BuildOAuthDiscoveryCandidates(t.Context(), server.Client(), endpoint, testLogger())
				require.NoError(t, err)
				require.NotNil(t, probe)
				require.Empty(t, probe.Error)
				require.Equal(t, server.URL+"/custom-metadata", probe.URL)
				require.Equal(t, DiscoverySourceWWWAuthenticate, candidates[0].Source)

				response, sourceURL, _, err := FetchOAuthMetadata(t.Context(), server.Client(), candidates, testLogger())
				require.NoError(t, err)
				require.Equal(t, server.URL+"/custom-metadata", sourceURL.String())
				require.JSONEq(t, fmt.Sprintf(`{"resource":"%s/mcp"}`, server.URL), string(response.Payload()))
			})
		}
	}
}

func TestBuildOAuthDiscoveryCandidatesPreservesCrossOriginHeaderDestination(t *testing.T) {
	t.Parallel()

	attacker := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	}))
	t.Cleanup(attacker.Close)

	var serverURL string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/public/mcp" {
			w.Header().Set("WWW-Authenticate", fmt.Sprintf(`Bearer resource_metadata="%s/metadata"`, attacker.URL))
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		http.NotFound(w, r)
	}))
	t.Cleanup(server.Close)
	serverURL = server.URL

	serverEndpoint, err := url.Parse(serverURL + "/public/mcp")
	require.NoError(t, err)
	candidates, probe, err := BuildOAuthDiscoveryCandidates(
		context.Background(),
		server.Client(),
		serverEndpoint,
		testLogger(),
	)
	require.NoError(t, err)
	require.NotNil(t, probe)
	require.True(t, probe.Attempted)
	require.Equal(t, attacker.URL+"/metadata", probe.URL)
	require.Empty(t, probe.Error)
	require.Equal(t, []string{
		attacker.URL + "/metadata",
		server.URL + "/.well-known/oauth-protected-resource/public/mcp",
		server.URL + "/.well-known/oauth-protected-resource",
	}, candidateURLsToStrings(candidates))
}

func TestBuildOAuthDiscoveryCandidatesFallbackToGET(t *testing.T) {
	t.Parallel()

	probePath := "/.well-known/oauth-protected-resource/custom"
	var serverURL string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/public/mcp" {
			if r.Method == http.MethodPost {
				w.WriteHeader(http.StatusNotFound)
				return
			}
			if r.Method == http.MethodGet {
				w.Header().Set("WWW-Authenticate", fmt.Sprintf(`Bearer resource_metadata="%s"`, serverURL+probePath))
				w.WriteHeader(http.StatusUnauthorized)
				return
			}
		}
		http.NotFound(w, r)
	}))
	t.Cleanup(server.Close)
	serverURL = server.URL

	serverEndpoint, err := url.Parse(server.URL + "/public/mcp")
	require.NoError(t, err)

	candidates, probe, err := BuildOAuthDiscoveryCandidates(
		context.Background(),
		server.Client(),
		serverEndpoint,
		testLogger(),
	)
	require.NoError(t, err)

	require.NotNil(t, probe)
	require.True(t, probe.Attempted)
	require.Equal(t, server.URL+probePath, probe.URL)
	require.Empty(t, probe.Error)
	require.NotEmpty(t, candidates)
	require.Equal(t, DiscoverySourceWWWAuthenticate, candidates[0].Source)

	expected := []string{
		server.URL + probePath,
		server.URL + "/.well-known/oauth-protected-resource/public/mcp",
		server.URL + "/.well-known/oauth-protected-resource",
	}
	require.Equal(t, expected, candidateURLsToStrings(candidates))
}

func TestBuildOAuthDiscoveryCandidatesDedupesProbe(t *testing.T) {
	t.Parallel()

	probePath := "/.well-known/oauth-protected-resource/public/mcp"
	var serverURL string
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost && r.URL.Path == "/public/mcp" {
			w.Header().Set("WWW-Authenticate", fmt.Sprintf(`Bearer resource_metadata=%s`, serverURL+probePath))
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		http.NotFound(w, r)
	}))
	t.Cleanup(server.Close)
	serverURL = server.URL

	serverEndpoint, err := url.Parse(server.URL + "/public/mcp")
	require.NoError(t, err)

	candidates, probe, err := BuildOAuthDiscoveryCandidates(
		context.Background(),
		server.Client(),
		serverEndpoint,
		testLogger(),
	)
	require.NoError(t, err)

	require.NotNil(t, probe)
	require.True(t, probe.Attempted)
	require.Equal(t, server.URL+probePath, probe.URL)
	require.NotEmpty(t, candidates)
	require.Equal(t, DiscoverySourceWWWAuthenticate, candidates[0].Source)

	expected := []string{
		server.URL + probePath,
		server.URL + "/.well-known/oauth-protected-resource",
	}
	require.Equal(t, expected, candidateURLsToStrings(candidates))
}

func TestBuildOAuthDiscoveryCandidatesMissingHeaderFallsBack(t *testing.T) {
	t.Parallel()

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost && r.URL.Path == "/public/mcp" {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		http.NotFound(w, r)
	}))
	t.Cleanup(server.Close)

	serverEndpoint, err := url.Parse(server.URL + "/public/mcp")
	require.NoError(t, err)

	candidates, probe, err := BuildOAuthDiscoveryCandidates(
		context.Background(),
		server.Client(),
		serverEndpoint,
		testLogger(),
	)
	require.NoError(t, err)

	require.NotNil(t, probe)
	require.True(t, probe.Attempted)
	require.Empty(t, probe.URL)
	require.NotEmpty(t, probe.Error)
	require.Len(t, candidates, 2)
	require.Equal(t, DiscoverySourceWellKnownPath, candidates[0].Source)
}

func TestBuildOAuthDiscoveryCandidatesProbeErrorBothMethods(t *testing.T) {
	t.Parallel()

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/public/mcp" {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		http.NotFound(w, r)
	}))
	t.Cleanup(server.Close)

	serverEndpoint, err := url.Parse(server.URL + "/public/mcp")
	require.NoError(t, err)

	candidates, probe, err := BuildOAuthDiscoveryCandidates(
		context.Background(),
		server.Client(),
		serverEndpoint,
		testLogger(),
	)
	require.NoError(t, err)

	require.NotNil(t, probe)
	require.True(t, probe.Attempted)
	require.Empty(t, probe.URL)
	require.NotEmpty(t, probe.Error)
	require.Contains(t, probe.Error, "GET")
	require.Len(t, candidates, 2)
	require.Equal(t, DiscoverySourceWellKnownPath, candidates[0].Source)
}

func TestBuildOAuthDiscoveryCandidatesMissingResourceMetadataFallsBack(t *testing.T) {
	t.Parallel()

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost && r.URL.Path == "/public/mcp" {
			w.Header().Set("WWW-Authenticate", `Bearer realm="demo"`)
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		http.NotFound(w, r)
	}))
	t.Cleanup(server.Close)

	serverEndpoint, err := url.Parse(server.URL + "/public/mcp")
	require.NoError(t, err)

	candidates, probe, err := BuildOAuthDiscoveryCandidates(
		context.Background(),
		server.Client(),
		serverEndpoint,
		testLogger(),
	)
	require.NoError(t, err)

	require.NotNil(t, probe)
	require.True(t, probe.Attempted)
	require.Empty(t, probe.URL)
	require.NotEmpty(t, probe.Error)
	require.Len(t, candidates, 2)
	require.Equal(t, DiscoverySourceWellKnownPath, candidates[0].Source)
}
